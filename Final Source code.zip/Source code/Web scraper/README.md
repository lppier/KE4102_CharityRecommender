# charity_scraper_js
Scraping www.charities.gov.sg using NightmareJS
